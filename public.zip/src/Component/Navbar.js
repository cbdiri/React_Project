import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import '../CSS/Navbar.css' 
class Navbar extends Component {
  v="/"
  v_Home=""
  v_Consulter=""
  v_Ajouter=""
  v_Supprimer=""
  v_Modifier=""
  
  render() {
    this.v=window.location.pathname; 
    if(this.v=="/"){this.v_Home="active"}
    if(this.v=="/Consulter"){this.v_Consulter="active"}
    if(this.v=="/Ajouter"){ this.v_Ajouter="active"}
    if(this.v=="/Supprimer"){this.v_Supprimer="active"}
    if(this.v=="/Modifier"){this.v_Modifier="active"}

    return      <div>  
        <ul > 
            <li  class={this.v_Home}> <Link to='/'> Home </Link>  </li>
            <li class={this. v_Consulter}> <Link to='/Consulter'> Consuler Films </Link>  </li>
            <li  class={this.v_Ajouter}> <Link to="/Ajouter"> Ajouter Films </Link>   </li>
            <li class={this.v_Supprimer}> <Link to="/Supprimer"> Suprimer Films </Link>  </li> 
            <li class={this.v_Modifier}> <Link to="/Modifier"> Modifier Films </Link>  </li> 

        </ul>
        
      </div>
      }
}
export default Navbar;
