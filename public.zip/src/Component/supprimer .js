import React, { Component } from 'react'
import Navbar from './Navbar' 
import '../CSS/Supprimer.css'

 let datas=localStorage.getItem('mydata4');

 
 export default class Supprimer extends Component {

constructor(props){
  super(props);
  this.state={    
    data:JSON.parse(datas),
  };
  
}

componentDidMount(){
  datas=localStorage.getItem('mydata4');
  this.setState({data:JSON.parse(datas)})
}



  handleDelete=(index)=>
  {
    localStorage.clear();
    

    let films=this.state.data.slice() 
    films.splice(index,1)
    localStorage.setItem('mydata4',JSON.stringify(films))
    this.setState({data:films}) 
    datas = localStorage.getItem('mydata4');

  }

  render() {
    return (<div>
      <div><Navbar/></div>
      <div className='container'>
        <h1>Liste des Films </h1>
        <div className='suprs'>
            <ol className='suprs' >
          {this.state.data.map((item, index) => (
            <p className='supr' key={index}>
            
              Name        : {item.Titre} <br/>
              Réalisateur : {item.Réalisateur}<br/>
              {/* Date_s      : {item.Date_s} <br/>
              Genre       : {item.Genre}<br/>
              Note        : {item.Note} <br/>
              subject     : {item.subject} <br/><br/> */}
              <button className='button-supr' onClick={()=>this.handleDelete(index)}> Supprimer </button>
            </p> 
          ))  }
        </ol>
        </div>
      </div>
      </div>
    );
  }
}

