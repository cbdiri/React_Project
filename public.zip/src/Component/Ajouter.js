import React, { Component } from 'react'
import Navbar from './Navbar';
import '../CSS/Ajouter.css'

export default class Ajouter extends Component {
  
  constructor(props) {
    super(props);
  
    this.state={
      Titre:"",
      Réalisateur:"",
      Date_s:"",
      Genre:"",
      Note:"",
      subject:"",
      img:"",
      data:[],
    };

    this.handilClick = this.handilClick.bind(this);
  }
  
  

  
  handelChange=(e)=>
  {
    let n=e.target.name;
    this.setState({[n]:e.target.value})
    
  }


  componentDidMount(){
    const datas = localStorage.getItem('mydata4');
    if(datas){ this.setState({data : JSON.parse(datas) }) }
  }

  handilClick(){
    const newData = { Titre:this.state.Titre , Réalisateur: this.state.Réalisateur ,Date_s:this.state.Date_s ,Genre: this.state.Genre ,Note : this.state.Note, subject:this.state.subject };
    const updatedData = [...this.state.data, newData];
    this.setState({ data: updatedData });
    localStorage.setItem('mydata4',JSON.stringify(updatedData))
  }

  render() {
    return (<div>
                    <div>
                      <Navbar/>
                    </div>
                    <div class="container">
                <div class="row">
                  <div class="col-25">
                    <label for="fname">Titre</label>
                  </div>
                  <div class="col-75">
                    <input onChange={this.handelChange} type="text"  name="Titre" placeholder="Titre de Film.."/>
                  </div>
                </div>

                <div class="row">
                  <div class="col-25">
                    <label for="lname">Réalisateur</label>
                  </div>
                  <div class="col-75">
                    <input onChange={this.handelChange} type="text"  name="Réalisateur" placeholder="Nom de Réalisateur.."/>
                  </div>
                </div>

                <div class="row">
                  <div class="col-25">
                    <label for="lname">Date de sortie</label>
                  </div>
                  <div class="col-75">
                    <input onChange={this.handelChange} type="Date"  name="Date_s" placeholder="année de sortie.."/>
                  </div>
                </div>
                
                <div class="row">
                  <div class="col-25">
                    <label for="country">Genre</label>
                  </div>
                  <div class="col-75">
                    <select default="Action" onChange={this.handelChange}  name="Genre">
                      <option value="Action ">Action </option>
                      <option value="Comédie">Comédie</option>
                      <option value="Science fiction">Science fiction</option>
                      <option value="Drame ">Drame </option>
                      <option value="Horreur">Horreur</option>
                    </select>
                  </div>
                </div>

                <div class="row">
                  <div class="col-25">
                    <label for="lname">Note</label>
                  </div>
                  <div class="col-75">
                    <input onChange={this.handelChange} type="number"  min={0} max={10}  name="Note" placeholder=".../10"/>
                  </div>
                </div>

                    <div class="row">
                  <div class="col-25">
                    <label for="subject">Description</label>
                  </div>
                  <div class="col-75">
                    <textarea onChange={this.handelChange} id="subject" name="subject" placeholder="écrire la discription .."></textarea>
                  </div>
                </div>
                <br/>
                
                <div class="row">
                </div>
                <button className='add' onClick={this.handilClick} > Submit </button>


              </div>
                
              {/* <h7>Titre : {this.state.Titre} </h7><br/>
               <h7>Réalisateur:  {this.state.Réalisateur} </h7><br/>              
              <h7>Date_s: {this.state.Date_s} </h7><br/>
             <h7>  Genre: {this.state.Genre} </h7><br/>
              <h7> Note: {this.state.Note} </h7><br/>
            <h7>   subject: {this.state.subject}</h7> */}
        

      </div>
    );
  }
}

