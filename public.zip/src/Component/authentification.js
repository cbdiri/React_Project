import '../CSS/auth.css';
import { Link } from 'react-router-dom';
import React, { Component  } from 'react'

class Authentification extends  Component{
    state={
        username:"",
        password:"",
        msg:"",
        ath:""
      }
      
      Handelchage=(e)=>{
        let n=e.target.name;    
        this.setState({[n]:e.target.value})
        this.setState({msg:""})

      }

      HandelClick=()=>
      { 
        if((this.state.username!="admin") || (this.state.password!="admin")){
        this.setState({msg:" Mot de passe ou Nom d'utilisateur erroné ! "})}
        
        if((this.state.username=="admin") && (this.state.password=="admin"))
        { this.setState({ath:"/"})     
         this.setState({msg:""})
          this.props.handelChange("ok")
        }   

      }
      Vrification()
        {
          if(this.state.ath!="/"){
            if((this.state.username=="admin") && (this.state.password=="admin"))
              {
                this.setState({ath:"/"})     
                //this.setState({msg:"ok"})
              }}
    }

      render(){
        {this.Vrification()};

      return (
        <div className='App_ath'>
        <div class="container">
          <form >

          <div class="row">
            <div class="col-25">
                <h2> Authentification  :</h2>
            </div>
          <div class="col-75">
            </div>
          </div>
      
          <div class="row">
            <div class="col-25">
                  <label for="fname">Login:</label>
             </div>
          <div class="col-75">
                <input className='login'  id="username" name="username" onChange={this.Handelchage}/> 
                </div>
          </div>
      
          <div class="row">
            <div class="col-25">
                  <label for="fname">Mot de passe :</label>
             </div>
          <div class="col-75">
                <input className='password' type="password" id="password" name="password" onChange={this.Handelchage}/> 
                </div>
          </div>
          <br/>
          
      <Link to={this.state.ath} > <button className='button-ath' onClick={this.HandelClick}> Se connecter </button></Link>

          </form>
          
          <br/><br/> 
      <h3  id="msg" className='msg'>{this.state.msg}</h3>    
        </div>
        </div>
        );
          
      }
      
}
export default Authentification;
