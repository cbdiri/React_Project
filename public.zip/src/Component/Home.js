import  { Component } from 'react'
import Navbar from './Navbar';
import '../CSS/Home.css'
class Home extends Component {



   render() {

     return ( <div>
     
     <div>
          <Navbar/>
      <div  className='App_Home'>
           <h1> page d'acceuill </h1>
       </div>
       
       </div>
       </div>
     );
   }
 }
export default Home ;
