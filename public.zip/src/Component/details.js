import { Component } from "react"
import Navbar from "./Navbar";

export default class Details extends Component{
    
    f=localStorage.getItem('film');
    film=JSON.parse(this.f);
    
    render()
    {
        return( <div>          
            
              <div>
                <Navbar/>
              </div>

              <div className='container'>
        <div className='conss'>
            <ol className='conss' >
              Name        : {this.film.Titre} <br/>
              Réalisateur : {this.film.Réalisateur}<br/>
              Date_s      : {this.film.Date_s} <br/>
              Genre       : {this.film.Genre}<br/>
              Note        : {this.film.Note} <br/>
              subject     : {this.film.subject} <br/><br/>      
        </ol>
        </div>
      </div>
            </div>

        );

    }

}