import React, { Component } from 'react'
import Navbar from './Navbar';
import   '../CSS/Consulter.css'
import { Link } from 'react-router-dom';

export default class Modifier extends Component {
  state={
    data1:[]
  }
  componentDidMount(){
    const datas1 = localStorage.getItem('mydata4');
    if(datas1){ this.setState({data1 : JSON.parse(datas1) }) }
  }
  Handelclick=(index)=>{
  let film=this.state.data1[index]
  localStorage.setItem('film',JSON.stringify(film))
  localStorage.setItem('index',JSON.stringify(index))

  }

  render() {
    return (<div>
      <div><Navbar/></div>
      <div className='container'>
        <h1>Liste des Films </h1>
        <div className='conss'>
            <ol className='conss' >
          {this.state.data1.map((item, index) => (
            <p className='cons' key={index}>
              Name        : {item.Titre} <br/>
              Réalisateur : {item.Réalisateur}<br/>
              {/* Date_s      : {item.Date_s} <br/>
              Genre       : {item.Genre}<br/>
              Note        : {item.Note} <br/>
              subject     : {item.subject} <br/><br/> */}
              <Link to="/Modifier/Film"> <button className='button_affiche' onClick={()=>this.Handelclick(index)}> Modifier</button></Link> 
              
            </p> 
          ))  }
        </ol>
        </div>
      </div>
      </div>
    );
  }
}

