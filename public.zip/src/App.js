import './App.css';
import React from 'react';
import Authentification from './Component/authentification';
import Home from './Component/Home';
import { Route, Routes } from 'react-router-dom';
import Consulter from './Component/Consuler';
import Ajouter from './Component/Ajouter';
import Supprimer from './Component/supprimer ';
import Details from './Component/details';
import Modifier from './Component/Modifier';
import Modifier_Film from './Component/Modifier_Film';


class App extends React.Component {
state={
  v_ath:""
}
get_v_ath=(e)=>{
  this.setState({v_ath:e})
}

  render(){
    if(this.state.v_ath!="ok")
    { 
      return  <div> 
             <Authentification handelChange={this.get_v_ath}/> 
             </div>
     }
    
    else if(this.state.v_ath=="ok") {
    return  <div>
            <Routes>        
            <Route path='/' element={<Home/>}/>
            <Route path='/Consulter' element={<Consulter/>}/>
            <Route path='/Consulter/details' element={<Details/>}></Route>
            <Route path='/Ajouter' element={<Ajouter/>}/>
            <Route path='/Supprimer' element={<Supprimer/>}/>
            <Route path='/Modifier' element={<Modifier/>}/>
            <Route path='/Modifier/Film' element={<Modifier_Film/>}/>



            </Routes>
        </div>
        
        }
  }
}
export default App;


